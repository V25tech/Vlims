import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-plant-management',
  templateUrl: './plant-management.component.html',
  styleUrls: ['./plant-management.component.css']
})
export class PlantManagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
